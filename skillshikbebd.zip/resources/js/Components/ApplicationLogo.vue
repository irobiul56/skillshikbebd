<template>
    <img :src="'/storage/image/logo.png'" class="h-20 w-40" alt="">
</template>
