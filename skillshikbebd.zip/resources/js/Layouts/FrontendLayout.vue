<script setup>
import Header from '@/Components/Header.vue';
import Footer from '@/Components/Footer.vue';
</script>

<template>
<Header/>

    <slot/>
    
<Footer/>
</template>

<style scoped>
</style>